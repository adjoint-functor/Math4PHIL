# I.5 小样本抽取诊断证据

本包支持报告附录 C 的有限例子：同一章、同一完整段落，在 minimal 与 guided 两种任务说明下各有一次原始代理运行。两者都获得完整冻结合同与 schema；guided 额外提供检查清单。材料只用于检查抽取记录、接口限制及事后修复的身份。

| 复查用途 | 文件 |
|---|---|
| 实际提交的希腊文与目标跨度 | [input/packet.json](input/packet.json) |
| 同章完整字符串、TEI 定位与 Bekker 锚 | [input/greek-I5.json](input/greek-I5.json) |
| 原典身份、抽取处理与第三方署名 | [source-note.md](source-note.md) |
| 预先规定的运行与判断方法 | [protocol.md](protocol.md) |
| 已知及未知运行条件、输入与输出散列 | [run-conditions.json](run-conditions.json) |
| 两种实际任务提示 | [minimal-prompt.txt](interface/minimal-prompt.txt)、[guided-prompt.txt](interface/guided-prompt.txt) |
| 当时完整合同及实际检查依赖 | [contract.md](interface/contract.md)、[annotation.schema.json](interface/annotation.schema.json)、[packet.schema.json](interface/packet.schema.json)、[validate.py](interface/validate.py) |
| 两份原始输出，含真实失败 | [minimal.raw.json](outputs/minimal.raw.json)、[guided.raw.json](outputs/guided.raw.json) |
| 另存修复、精确补丁及说明 | [minimal.repaired.json](repair/minimal.repaired.json)、[minimal.repair.patch.json](repair/minimal.repair.patch.json)、[repair-note.md](repair/repair-note.md) |
| 既有结构核验结果 | [minimal 原始结果](checks/minimal.raw.validation.json)、[guided 原始结果](checks/guided.raw.validation.json)、[minimal 修复结果](checks/minimal.repaired.validation.json) |
| 文件身份与本次离线核对 | [manifest.json](manifest.json)、[verify_offline.py](verify_offline.py)、[offline-check.json](checks/offline-check.json) |

## 关键判断及其定位

原文码点 `[1135,1202)` 是“称这样生活的人幸福”并保留例外的整句。区间按 Python 字符串的 Unicode 码点计数，零基、左闭右开，不是印刷行号。

minimal 原始文件 `/statements/7`（`s8`）的 `n20` 写成 `happy(args=[], subject={ref:r14})`。实际检查器的 `SIGNATURES["happy"]` 要求唯一参数为 `agent`，额外 `subject` 仅允许出现在行为谓词中。因此同一节点触发 `ARITY` 和 `SUBJECT`，不是两项独立的希腊文语义错误。合同表格在参数列也用 subject 指被评价者，读时须与额外字段 `subject` 区分；两份文件保持原字节，未为本附录事后修改接口。

guided 的 `abstentions` 中保留这整句及无法表示例外的理由，原始文件通过结构检查。minimal 则将所存主句标为 `consequent_fragment`，并在 `abstentions` 中保留未表示的例外。修复只移置 minimal 的一个角色，不把片段补成完整断言。

本包没有把命题数、弃答数、跨度重复出现次数或 AI 审阅次数用作正确率分母。只有同一文本在两种条件下各一次原始运行；修复是派生副本。I.8 与其他开发例没有纳入本附录的诊断评价。

## 离线复查

仅需 Python 3 和标准库，不调用模型、不联网。可从任意工作目录执行：

```bash
python /path/to/diagnostic-I5/verify_offline.py
```

脚本核对文件散列、输入同一性、原始输出身份、修复补丁及逆向恢复；随后用原样检查器重算并比较三份既有结构结果。预期 minimal 原始输出为 `ok=false`，错误恰为同一 `n20` 的 `ARITY`、`SUBJECT`；guided 原始输出与 minimal 修复副本为 `ok=true`。脚本退出成功表示这些已声明的事实相符。直接运行 `validate.py` 检查 minimal 原始文件时，退出码 1 正是保留失败的预期结果。

如需另存本次核对结果：

```bash
python /path/to/diagnostic-I5/verify_offline.py --output /tmp/diagnostic-I5-check.json
```

结构检查限于格式、声明类型、词法绑定、引用、给定字符串与声明的词边界规则；它不裁决希腊文释读，也不证明原文语义已被完整表示。原典审阅仍属 AI 意见，后台模型快照、采样参数及预训练接触未知。两份任务提示文件及已保存的运行限制可复查；完整后台请求、系统提示和编排轨迹不在这些保存记录中，不能承诺逐字重现旧代理输出。

## 原始材料与公开包装

协议、完整合同、两份提示、两个输入记录、原始输出、修复副本、补丁、检查器、schema 及三份既有检查结果均为字节不变的复制；原文件中的历史例子编号与路径保持原样。合同末尾的旧路径对应本包 `interface/validate.py` 等同名文件；开发回归和目的图投影不属于本附录所需的离线检查，未随包收入。

`run-conditions.json` 是明确标记的元数据派生件：移除内部代理协调标识，将文件位置映射为包内相对路径，保留影响判断的运行条件和原始文件散列。`repair/repair-note.md` 同样为派生说明。没有重写提示或原始输出，也没有把包装文件伪称为原始运行记录。历史完整冻结清单还涵盖开发材料，本包只复核所收录依赖，不声称重做全部历史冻结检查。
