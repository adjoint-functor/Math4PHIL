# 希腊文底本与本次输入

作者：Aristotle。希腊文题名：*Ἠθικὰ Νικομάχεια*。编者：Ingram Bywater。印刷底本：*Aristotelis Ethica Nicomachea*. Oxford: Clarendon Press, 1894，Oxford Classical Texts。

实际数字源为 Perseus Digital Library 的 TEI/XML，版本 URN 为 `urn:cts:greekLit:tlg0086.tlg010.perseus-grc2`。文件头列出 Perseus Project, Tufts University 为 sponsor，Gregory Crane 为 principal，Lisa Cerrato、William Merrill、Elli Mylonas、David Smith 为制作监督人员；funder 为 The Annenberg CPB/Project。数字出版者为 Trustees of Tufts University，Medford, MA；发布记录为 Perseus 2.0（1996）。实际固定文件包括其后的数字修订，不能把 1996 当作当前全部文件的最后修订年。

上游为 [PerseusDL/canonical-greekLit](https://github.com/PerseusDL/canonical-greekLit)，数据路径为 `data/tlg0086/tlg010/tlg0086.tlg010.perseus-grc2.xml`。固定 Git blob 为 `e8a43ddc7d643fca148f1dda18dc6d34528a9b2b`；它是文件对象号，不是提交号。完整 TEI 文件的 SHA-256 为 `a203a8d2e793b06884b135c23a5726ce36fc4796a6651589becb7cdf86ee42ae`，原文件名为 `tlg0086.tlg010.perseus-grc2.xml`。

本包只收入实际诊断使用的 I.5。`input/greek-I5.json` 是固定源文件的既有抽取记录；`input/packet.json` 是当时实际提交的输入。章内只有一个完整 TEI 段落，读法长度为 1649 个 Unicode 码点。抽取只统一既定空白；通用读法规则保留 `add`、略去 `del`，而 I.5 的 `editorial` 数组为空。字母、重音、大小写和标点未作规范化。文本字符串的 UTF-8 SHA-256 为 `310d450a5b8d92da6b9994a9cb2c2f1cf848ec1edf36a2fe626f46aa0fa24fe3`；这与整个 JSON 文件散列的对象不同。

输入摘录及其结构化定位是从数字 TEI 制作的衍生材料；本次包装未再改变两个 JSON 的字节。原 TEI 的 availability 声明为 [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/)，希腊文摘录保留该来源与许可身份。完整固定 TEI 及原样头部随报告的原典包另列；本小包用于复查实际输入和已保存输出，不单独重做 TEI 抽取，也不依赖完整 TEI 才能运行结构检查。

输入不附 Ross 或 Rackham 英译。报告项目此前曾以英译辅助阅读；原典判定仍依据固定希腊文，不以英译替代。经典文本的模型预训练接触情况未知。
