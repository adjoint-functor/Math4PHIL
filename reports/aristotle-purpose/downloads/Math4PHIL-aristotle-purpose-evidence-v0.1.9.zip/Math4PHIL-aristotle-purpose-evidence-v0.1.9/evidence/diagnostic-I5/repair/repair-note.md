# minimal 的另存结构修复

本文件为公开包的派生说明，依据既有 `repair-report.md`、`repair-record.json` 与实际 JSON 差异编写，路径已映射为本包位置。原始输出、修复副本、补丁和既有检查结果均保持字节不变。

唯一改动位于 `outputs/minimal.raw.json` 的 JSON Pointer `/statements/7/formula/body/body/body/body`，即 `s8/n20`：把 `args=[]` 改为 `args=[{"ref":"r14"}]`，删除额外 `subject`。`r14` 仍是原先的被评价者。检查器要求 `happy` 有一个 `agent` 参数且不含行为主语槽；原始输出的 `ARITY`、`SUBJECT` 均来自这个节点。

| 身份 | SHA-256 | 结构结果 |
|---|---|---|
| 原始输出 | `ea0cae2aface26b4bf6bdd338845fd9746f211fce27b02c3bc235b5107e83234` | `ok=false`；同节点两条报错 |
| 另存修复 | `3142eb89936615e2ba1d33bb22d9890e748292a797e762c94b5a2227ca756759` | `ok=true`；0 条报错 |

修复是在原文审阅之后另行制作的结构处理，没有新模型运行。其余 JSON 值全部不变，`s8` 的 `consequent_fragment` 标记与例外无法表示的弃答说明都保留。修复不补充条件、例外、指称或量化域，也不认证整句解释。

`minimal.repair.patch.json` 保存实际补丁。`verify_offline.py` 重新应用它，核对结果等于另存修复，再恢复原来的参数和字段，核对结果等于原始 JSON；同时用散列检查原始文件字节未改。可逆的 JSON 结构差异与原始字节的身份分别检查。
