#!/usr/bin/env python3
"""Check the saved I.5 evidence bundle offline; never run an annotating model."""
import argparse
import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
BUNDLE_ROOT = Path(__file__).resolve().parent
NODE_POINTER = "/statements/7/formula/body/body/body/body"
CLAUSE = "τὸν δʼ οὕτω ζῶντα οὐδεὶς ἂν εὐδαιμονίσειεν, εἰ μὴ θέσιν διαφυλάττων"


def read_json(relative):
    return json.loads((BUNDLE_ROOT / relative).read_text(encoding="utf-8"))


def digest(relative):
    return hashlib.sha256((BUNDLE_ROOT / relative).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pointer(document, path):
    current = document
    for part in path.strip("/").split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        current = current[int(part)] if isinstance(current, list) else current[part]
    return current


def verify():
    manifest = read_json("manifest.json")
    listed = set()
    for entry in manifest["files"]:
        relative = entry["path"]
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts,
                "Manifest path leaves the evidence bundle")
        require(relative not in listed, "Duplicate manifest path")
        listed.add(relative)
        require((BUNDLE_ROOT / relative).stat().st_size == entry["bytes"], relative + ": byte count")
        require(digest(relative) == entry["sha256"], relative + ": SHA-256")
    actual_files = {p.relative_to(BUNDLE_ROOT).as_posix()
                    for p in BUNDLE_ROOT.rglob("*") if p.is_file()}
    allowed_generated = {"manifest.json", "checks/offline-check.json"}
    require(actual_files - listed <= allowed_generated, "Unexpected files in the evidence bundle")

    conditions = read_json("run-conditions.json")
    require(digest(conditions["shared_input"]) == conditions["shared_input_sha256"], "Shared input identity")
    require(digest(conditions["greek_chapter_record"]) == conditions["greek_chapter_record_sha256"],
            "Greek chapter record identity")
    require(len(conditions["conditions"]) == 2, "Exactly two saved prompt conditions")
    require({c["name"] for c in conditions["conditions"]} == {"minimal", "guided"}, "Condition names")
    for condition in conditions["conditions"]:
        require(condition["original_agent_runs"] == 1, "One original agent run per condition")
        require(digest(condition["prompt"]) == condition["prompt_sha256"], "Original prompt identity")
        require(digest(condition["raw_output"]) == condition["raw_output_sha256"], "Original output identity")
        require((BUNDLE_ROOT / condition["raw_output"]).stat().st_size == condition["raw_output_bytes"],
                "Original output byte count")

    packet = read_json("input/packet.json")
    greek = read_json("input/greek-I5.json")
    require(len(packet["contexts"]) == 1 and len(packet["targets"]) == 1, "One shared text and target")
    context, target = packet["contexts"][0], packet["targets"][0]
    require(context["text"] == greek["text"], "Packet/chapter text equality")
    require(len(greek["paragraphs"]) == 1 and len(greek["text"]) == 1649, "Full I.5 paragraph length")
    require((context["start"], context["end"], target["start"], target["end"]) == (0, 1649, 0, 1649),
            "Full shared target span")
    require(hashlib.sha256(greek["text"].encode("utf-8")).hexdigest() == greek["text_sha256_utf8"]
            == context["text_sha256_utf8"] == conditions["source_text_sha256_utf8"], "Greek text digest")
    require(greek["text"][1135:1202] == CLAUSE, "Quoted Greek clause at the declared offsets")

    minimal = read_json("outputs/minimal.raw.json")
    guided = read_json("outputs/guided.raw.json")
    repaired = read_json("repair/minimal.repaired.json")
    original_node = pointer(minimal, NODE_POINTER)
    require(original_node == {"id": "n20", "op": "atom", "pred": "happy", "args": [],
                              "subject": {"ref": "r14"}}, "Actual original n20 slot error")
    patch = read_json("repair/minimal.repair.patch.json")
    require(patch == [
        {"op": "replace", "path": NODE_POINTER + "/args", "value": [{"ref": "r14"}]},
        {"op": "remove", "path": NODE_POINTER + "/subject"}], "The saved two-operation repair patch")
    patched = copy.deepcopy(minimal)
    for operation in patch:
        parent_path, key = operation["path"].rsplit("/", 1)
        parent = pointer(patched, parent_path)
        require(key in parent, "Repair touches an existing field")
        if operation["op"] == "replace":
            parent[key] = copy.deepcopy(operation["value"])
        else:
            del parent[key]
    require(patched == repaired, "Patch yields the saved repair and no other JSON change")
    restored = copy.deepcopy(repaired)
    restored_node = pointer(restored, NODE_POINTER)
    restored_node["args"] = []
    restored_node["subject"] = {"ref": "r14"}
    require(restored == minimal, "Reverse change restores the original JSON")
    require(minimal["statements"][7]["force"] == repaired["statements"][7]["force"]
            == "consequent_fragment", "Repair retains the fragment status")
    require(any(e["start"] == 1135 and e["end"] == 1202 and e["text"] == CLAUSE
                for a in guided["abstentions"] for e in a["evidence"]),
            "Guided abstention preserves the full quoted clause")
    require(any(e["start"] == 1135 and e["end"] == 1202 and e["text"] == CLAUSE
                for a in minimal["abstentions"] for e in a["evidence"]),
            "Minimal abstention preserves the unrepresented exception clause")

    spec = importlib.util.spec_from_file_location("saved_i5_validator", BUNDLE_ROOT / "interface/validate.py")
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    require(validator.SIGNATURES["happy"] == [{"agent"}] and "happy" not in validator.BEHAVIOR,
            "Frozen happy role signature")
    validations = {}
    for name, annotation in (("minimal.raw", minimal), ("guided.raw", guided), ("minimal.repaired", repaired)):
        result = validator.validate(packet, annotation)
        require(result == read_json("checks/" + name + ".validation.json"),
                name + ": deterministic recheck agrees with the saved result")
        validations[name] = {key: result[key] for key in ("ok", "error_count", "errors", "counts")}
    require({(e["code"], e["path"]) for e in validations["minimal.raw"]["errors"]}
            == {("ARITY", "n20"), ("SUBJECT", "n20")}, "Two diagnostics belong to the same original node")
    require(not validations["minimal.raw"]["ok"] and validations["guided.raw"]["ok"]
            and validations["minimal.repaired"]["ok"], "Expected original-failure and repair identities")

    return {
        "bundle_check_ok": True,
        "hash_checked_files": len(listed),
        "source_scope": {"chapter": "1.5", "paragraphs": 1, "codepoints": 1649,
                         "original_agent_runs": 2, "runs_per_prompt_condition": 1,
                         "new_model_runs_during_recheck": 0},
        "repair": {"changed_original_nodes": 1, "patch_matches_saved_repair": True,
                   "reverse_change_restores_original_json": True, "fragment_status_preserved": True},
        "validation": validations,
        "claim_limit": "Offline identity and structural checks only. No Greek-semantic certification, accuracy estimate, new model execution, or proof of the philosophical model.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional new JSON check result path")
    args = parser.parse_args()
    result = verify()
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
