#!/usr/bin/env python3
"""Validate the frozen finite interface, not Greek meaning or compatible contexts."""
import argparse
import hashlib
import json
import re
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def schema_errors(value, schema, root, path="$", depth=0):
    """Interpreter for exactly the JSON Schema subset used by the two bundled schemas."""
    if depth > 160:
        return [f"{path}: nesting limit exceeded"]
    if "$ref" in schema:
        return schema_errors(value, root["$defs"][schema["$ref"].split("/")[-1]], root, path, depth + 1)
    if "oneOf" in schema:
        trials = [schema_errors(value, x, root, path, depth + 1) for x in schema["oneOf"]]
        if sum(not x for x in trials) != 1:
            return [f"{path}: must match exactly one permitted shape"]
        return []
    errors = []
    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: unexpected constant")
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: outside finite vocabulary")
    typ = schema.get("type")
    good = {"object": isinstance(value, dict), "array": isinstance(value, list),
            "string": isinstance(value, str), "integer": type(value) is int,
            "null": value is None, "boolean": type(value) is bool}
    if typ and not good[typ]:
        return errors + [f"{path}: expected {typ}"]
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                errors.append(f"{path}.{key}: missing")
        if schema.get("additionalProperties") is False:
            for key in value.keys() - props.keys():
                errors.append(f"{path}.{key}: undeclared field")
        for key in value.keys() & props.keys():
            errors += schema_errors(value[key], props[key], root, path + "." + key, depth + 1)
    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0):
            errors.append(f"{path}: too few entries")
        for i, item in enumerate(value):
            errors += schema_errors(item, schema.get("items", {}), root, f"{path}[{i}]", depth + 1)
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0) or len(value) > schema.get("maxLength", len(value)):
            errors.append(f"{path}: invalid code-point length")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errors.append(f"{path}: identifier/pattern mismatch")
    if type(value) is int and value < schema.get("minimum", value):
        errors.append(f"{path}: below minimum")
    return errors


def word_char(ch):
    return bool(ch) and (unicodedata.category(ch)[0] in "LMN" or ch in "_'’ʼ᾽᾿")


def all_spans(value, path="$"):
    if isinstance(value, dict):
        if {"context_id", "start", "end", "text"} <= value.keys():
            yield path, value
        else:
            for key, item in value.items():
                yield from all_spans(item, path + "." + key)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from all_spans(item, f"{path}[{i}]")


def nodes(formula):
    yield formula
    for key in ("body", "antecedent", "consequent"):
        if key in formula:
            yield from nodes(formula[key])
    for child in formula.get("items", []):
        yield from nodes(child)


BEHAVIOR = {"choose", "pursue", "desire", "choose_for", "pursue_for", "desire_for",
            "own_sake_choose", "own_sake_pursue", "own_sake_desire"}
VALUE = {"good", "practical"}
SIGNATURES = {**{x: [VALUE] for x in BEHAVIOR if not x.endswith("_for")},
              **{x: [VALUE, VALUE] for x in BEHAVIOR if x.endswith("_for")},
              "end_of": [{"good"}, {"practical"}], "about": [{"argument"}, {"good"}],
              "is_end": [{"good"}], "is_practical_good": [VALUE], "is_final": [VALUE],
              "self_sufficient": [VALUE], "result_occurs": [VALUE], "happy": [{"agent"}],
              "equal": [None, None], "compare": [{"good"}, {"good"}]}


def validate(packet, annotation):
    errors, bindings = [], []

    def fail(code, path, message):
        errors.append({"code": code, "path": path, "message": message})

    for name, value in (("packet", packet), ("annotation", annotation)):
        schema = json.loads((ROOT / (name + ".schema.json")).read_text())
        for error in schema_errors(value, schema, schema):
            fail("SCHEMA", name, error)
    if errors:
        return {"ok": False, "error_count": len(errors), "errors": errors, "bindings": []}

    def table(items, name, field="id"):
        result = {}
        for item in items:
            if item[field] in result:
                fail("DUPLICATE_ID", name, item[field])
            result[item[field]] = item
        return result

    contexts = table(packet["contexts"], "contexts", "context_id")
    targets = table(packet["targets"], "targets", "target_id")
    for cid, context in contexts.items():
        if context["end"] - context["start"] != len(context["text"]):
            fail("PACKET_LENGTH", cid, "end-start must equal code-point length")
        if hashlib.sha256(context["text"].encode()).hexdigest() != context["text_sha256_utf8"]:
            fail("PACKET_HASH", cid, "context bytes differ from the packet digest")
        if (context["start"] == 0) != (context["left_guard"] == ""):
            fail("PACKET_GUARD", cid, "a noninitial context needs the preceding source character")
    if annotation["packet_id"] != packet["packet_id"]:
        fail("PACKET_ID", "$", "annotation belongs to a different packet")

    def check_span(span, path):
        context = contexts.get(span["context_id"])
        if not context:
            fail("REFERENCE", path, "unknown context"); return
        lo, hi = span["start"] - context["start"], span["end"] - context["start"]
        text = context["text"]
        if not (0 <= lo < hi <= len(text)):
            fail("SPAN_RANGE", path, "empty or outside its context"); return
        if text[lo:hi] != span["text"]:
            fail("SPAN_TEXT", path, "not the exact original code-point substring")
        before = text[lo - 1] if lo else context["left_guard"]
        after = text[hi] if hi < len(text) else context["right_guard"]
        if (word_char(before) and word_char(text[lo])) or (word_char(text[hi - 1]) and word_char(after)):
            fail("SPAN_BOUNDARY", path, "span starts or ends inside a word under the declared character rule")

    for path, span in all_spans(annotation):
        check_span(span, path)
    for tid, target in targets.items():
        context = contexts.get(target["context_id"])
        if not context:
            fail("REFERENCE", tid, "unknown target context"); continue
        lo, hi = target["start"] - context["start"], target["end"] - context["start"]
        check_span({**target, "text": context["text"][max(lo, 0):max(hi, 0)]}, tid)

    objects = table(annotation["objects"], "objects")
    refs = table(annotation["referents"], "referents")
    mentions = table(annotation["mentions"], "mentions")
    domains = table(annotation["domains"], "domains")
    table(annotation["statements"], "statements")
    ref_cache, domain_cache = {}, {}

    def ref_type(rid, stack=()):
        if rid in ref_cache:
            return ref_cache[rid]
        if rid not in refs or rid in stack:
            fail("REFERENCE", rid, "missing referent or cyclic referent base"); return None
        ref = refs[rid]
        if ref["kind"] == "named":
            item = objects.get(ref["object"])
            if not item:
                fail("REFERENCE", rid, "unknown interpreted object"); return None
            typ = item["sort"], item["level"]
        elif ref["kind"] == "anonymous":
            typ = ref["sort"], ref["level"]
        else:
            base = ref_type(ref["base"], stack + (rid,))
            if not base:
                return None
            typ = base[0], ref["level"]
        ref_cache[rid] = typ
        return typ

    for rid in refs:
        ref_type(rid)
    ref_mentions = {}
    for mid, mention in mentions.items():
        rid = mention["referent"]
        ref_type(rid)
        previous = mention["inherits_from"]
        if previous:
            if previous not in mentions or mentions[previous]["referent"] != rid:
                fail("INHERITANCE", mid, "inheritance must link a mention of the same discourse referent")
            seen, current = {mid}, previous
            while current in mentions:
                if current in seen:
                    fail("INHERITANCE", mid, "cyclic mention inheritance"); break
                seen.add(current); current = mentions[current]["inherits_from"]
        prior = ref_mentions.setdefault(rid, [])
        if refs.get(rid, {}).get("kind") == "restricted":
            if prior and not previous:
                fail("INHERITANCE", mid, "reused restricted referent requires an explicit earlier-mention link")
            if previous and previous not in prior:
                fail("INHERITANCE", mid, "restricted inheritance must point to an earlier listed mention")
            if not prior and not any(s["context_id"] == mention["span"]["context_id"] and
                                    s["start"] < mention["span"]["end"] and s["end"] > mention["span"]["start"]
                                    for s in refs[rid]["evidence"]):
                fail("INHERITANCE", mid, "introductory mention must overlap the declared restriction evidence")
        prior.append(mid)

    def domain_type(did, stack=()):
        if did in domain_cache:
            return domain_cache[did]
        if did not in domains or did in stack:
            fail("REFERENCE", did, "missing domain or cyclic domain inclusion"); return None
        domain = domains[did]
        if domain["kind"] == "open":
            item = objects.get(domain["object"])
            if not item:
                fail("REFERENCE", did, "unknown domain restrictor object"); return None
            typ = item["sort"], domain["level"]
        else:
            types = [ref_type(x) for x in domain["members"]]
            types += [domain_type(x, stack + (did,)) for x in domain["subdomains"]]
            if not types or any(t is None or t[1] == "unspecified" for t in types) or len(set(types)) != 1:
                fail("DOMAIN_TYPE", did, "enumeration must be nonempty and have one resolved member sort and level"); return None
            if len(domain["members"]) != len(set(domain["members"])) or len(domain["subdomains"]) != len(set(domain["subdomains"])):
                fail("DOMAIN_TYPE", did, "duplicate enumerated member or subdomain")
            typ = types[0]
        domain_cache[did] = typ
        return typ

    for did in domains:
        domain_type(did)
    global_nodes = set()
    for statement in annotation["statements"]:
        sid = statement["id"]
        target = targets.get(statement["target_id"])
        if not target:
            fail("REFERENCE", sid, "unknown target")
        sr = statement["voice"]["speaker_ref"]
        if sr and (ref_type(sr) or (None,))[0] != "agent":
            fail("TYPE", sid, "identified speaker must be an agent")
        local_nodes = list(nodes(statement["formula"]))
        node_ids = {n["id"] for n in local_nodes}
        for node in local_nodes:
            if node["id"] in global_nodes:
                fail("DUPLICATE_ID", sid, node["id"])
            global_nodes.add(node["id"])
        supported = [s["node"] for s in statement["support"]]
        if len(supported) != len(set(supported)) or set(supported) != node_ids:
            fail("SUPPORT_COVERAGE", sid, "every AST node needs exactly one support record in its own statement")
        for support in statement["support"]:
            if support["tag"] == "ellipsis" and not support["antecedent_evidence"]:
                fail("SUPPORT_LINK", support["node"], "ellipsis needs an explicit antecedent span")
        if target and not any(sp["context_id"] == target["context_id"] and sp["start"] < target["end"] and sp["end"] > target["start"]
                              for support in statement["support"] for sp in support["evidence"]):
            fail("TARGET_SCOPE", sid, "no statement evidence overlaps the declared target")
        seen_vars, occurrences = set(), {}

        def term_type(term, env, path):
            if "ref" in term:
                return ref_type(term["ref"])
            if "unknown" in term:
                return term["unknown"], "unspecified"
            name = term["var"]
            if name not in env:
                fail("FREE_VAR", path, name); return None
            occurrences.setdefault(name, []).append(path)
            return env[name]

        def visit(node, env):
            nid, op = node["id"], node["op"]
            if op == "atom":
                pred, args = node["pred"], node["args"]
                signature = SIGNATURES[pred]
                if len(args) != len(signature):
                    fail("ARITY", nid, f"{pred} requires {len(signature)} value argument(s)")
                types = [term_type(t, env, f"{nid}.args[{i}]") for i, t in enumerate(args)]
                for i, (typ, allowed) in enumerate(zip(types, signature)):
                    if typ and allowed and typ[0] not in allowed:
                        fail("TYPE", f"{nid}.args[{i}]", f"{typ[0]} is not a permitted role sort")
                if pred in BEHAVIOR:
                    if "subject" not in node:
                        fail("SUBJECT", nid, "behavior needs a subject, including an explicit unknown subject")
                    elif (term_type(node["subject"], env, nid + ".subject") or (None,))[0] != "agent":
                        fail("TYPE", nid + ".subject", "behavior subject must be an agent")
                elif "subject" in node:
                    fail("SUBJECT", nid, "this relation has no behavior-subject slot")
                if pred == "compare":
                    if "dimension" not in node or "relation" not in node:
                        fail("COMPARISON", nid, "comparison dimension and direction are mandatory")
                    if any("unknown" in t for t in args) or any(t and t[1] == "unspecified" for t in types):
                        fail("COMPARISON", nid, "both comparison roles need resolved comparable types")
                elif "dimension" in node or "relation" in node:
                    fail("COMPARISON", nid, "comparison fields are only permitted on compare")
                if pred in {"equal", "compare"} and len(types) == 2 and all(types) and types[0] != types[1]:
                    fail("TYPE", nid, "comparison/equality roles must have matching sort and level")
            elif op == "quant":
                name = node["var"]
                if name in seen_vars:
                    fail("BINDER", nid, "variable shadowing/rebinding is excluded from this finite language")
                seen_vars.add(name)
                typ = domain_type(node["domain"])
                visit(node["body"], {**env, name: typ or ("invalid", "unspecified")})
                uses = occurrences.get(name, [])
                if not uses:
                    fail("UNUSED_BINDER", nid, "quantifier does not bind an occurring role; null/empty roles cannot be targets")
                bindings.append({"statement": sid, "binder": nid, "variable": name, "domain": node["domain"],
                                 "scope_node": node["body"]["id"], "occurrences": uses})
            elif op == "attitude":
                if (term_type(node["holder"], env, nid + ".holder") or (None,))[0] != "agent":
                    fail("TYPE", nid, "attitude holder must be an agent")
                visit(node["body"], env)
            elif op in {"and", "or"}:
                for child in node["items"]:
                    visit(child, env)
            elif op == "if":
                visit(node["antecedent"], env); visit(node["consequent"], env)
            else:
                visit(node["body"], env)

        visit(statement["formula"], {})
    for entry in annotation["abstentions"]:
        if entry["target_id"] not in targets:
            fail("REFERENCE", "abstentions", "unknown target")
    return {"ok": not errors, "error_count": len(errors), "errors": errors, "bindings": bindings,
            "counts": {"statements": len(annotation["statements"]), "ast_nodes": len(global_nodes),
                       "mentions": len(mentions), "span_occurrences": sum(1 for _ in all_spans(annotation))},
            "claim_limit": "Syntax, declared types, lexical variable scope, reference links and supplied-text spans only; no Greek-semantic or Omega certification."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("packet"); parser.add_argument("annotation"); parser.add_argument("--output")
    args = parser.parse_args()
    result = validate(json.loads(Path(args.packet).read_text()), json.loads(Path(args.annotation).read_text()))
    output = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(output)
    else:
        print(output, end="")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
