# 原文关系接口 0.2.4-finite-1

项目：《哲学体系的范畴重构》；本轮日期 2026-10-27，Asia/Shanghai。
此合同先于新材料冻结，只依据 round-005 的许可输入、原始输出、诊断、修订建议、独立审阅及 v0.2.3 计算草稿第 12 节制定。它是有限标注语言，不是通用知识平台。

## 输入、输出与信任边界

输入采用 `packet.schema.json`；输出采用 `annotation.schema.json`；实际检查器是 `validate.py`。仅使用 Python 标准库。两个 JSON Schema 中使用的有限子集由检查器直接执行；不是声称实现了全部 JSON Schema 标准。

Packet 包含 `packet_id/source_id/reading_id`、若干原文窗口和待标注 targets。窗口保存章内 `[start,end)`、逐字 `text`、UTF-8 SHA-256、紧邻窗口左右各一个原文字符 `left_guard/right_guard`。左空串只用于章首，右空串由制包者声明为章尾。正文与 guard 必须由可靠底本程序提取，不能由标注模型补写。检查器验证 packet 内部长度和散列，不能自行认证底本、读法、guard 或校勘取舍。

输出的三层分开保存：

| 层 | 作用 | 不自动推出什么 |
|---|---|---|
| `mentions` | 一次逐字出现及其证据跨度 | 不把每次提及都当成新对象 |
| `objects` | 经解释的对象，声明 sort 与 kind/individual 层级 | 概念的一般性不等于全体实例的量化 |
| `referents` | 当前话语指称：named、restricted 或 anonymous | 同一概念下的受限集合不等于整个概念域 |

`r`、`o`、`m`、`d`、`s`、`n`、`v` 后只能跟正整数。名称只用于定位，不携带逻辑意义。对象标签仍需原文审阅；给变量起名不能为原文补出具体目的。未指名端点使用 typed `unknown` 或 anonymous 指称；存在量词的见证使用绑定变量。它们都不是可直接导图的命名端点。

## 有限公式语言

每条 statement 有独立闭合 AST。每个节点有唯一 `n` ID。只接受以下节点：

```text
atom(pred,args[,subject][,dimension,relation])
not(body)                         and(items) / or(items)
if(antecedent,consequent)         quant(all|some|at_least_two,v,d,body)
modal(potential|apparent|necessary|possible|unknown,body)
temporal(always|sometimes,body)   attitude(believes|claims,holder,body)
term := {ref:r} | {var:v} | {unknown:sort,reason:unnamed|unexpressed|unresolved}
```

这是 JSON 结构的简记，不是另一种可提交的字符串语法。真正语法在 schema；普通文字释义不能替代 AST。变量只由词法上包围它的 `quant` 绑定，`body` 就是明示作用域。禁止自由变量、重复绑定、遮蔽与空绑定；至少有一个实际角色使用该变量。`not(all(...))` 表示非全称，不能改写成 `all(not(...))`。`at_least_two` 是至少两个满足 body 的成员，不附着于空角色。

量词域只能是 `domains` 中声明的域：open 域指定对象 restrictor 和成员层级；enumerated 域显式列出成员或同型子域。列举成员不可为空、不可重复、不得混合不相容的 sort/level。域是否符合希腊文仍由原文审阅决定。

有限谓词与角色如下；`good/practical` 表示二者之一，不表示二者等同：

| 谓词 | args 顺序 | 额外要求 |
|---|---|---|
| choose / pursue / desire | item: good/practical | subject: agent，缺省主语须显式 unknown |
| choose_for / pursue_for / desire_for | item, end: good/practical | subject: agent |
| own_sake_choose / own_sake_pursue / own_sake_desire | item: good/practical | 一个对象参数；subject 只是行为主体语境 |
| end_of | end: good, item: practical | 不与 choose_for 合并 |
| about | argument: argument, topic: good | 将论证与所论善分开 |
| is_end | item: good | — |
| is_practical_good / is_final / self_sufficient / result_occurs | item: good/practical | — |
| happy | subject: agent | 信念内的 happy 不断言客观成功 |
| equal | left, right | 两侧 sort 与 level 相同 |
| compare | left, right: good | 两侧同型；必填 dimension 和 relation |

`compare.dimension` 限 choiceworthiness、finality、goodness；`relation` 限 gt、eq、ge。`τελειότερον` 的 finality 比较不能仅靠一个含混的 comparison_item 槽保存。比较两侧须是有类型的对象项，不能拿论证当善，也不能把一个域名直接当作比较对象。更细量值、嵌套意向、跨句存在见证、不能忠实表示的关系，记入 `abstentions`，不要扩充词表或使用自由文本假装已解析。

## 一般性、列举与限定继承

named 的 kind 指称可以是“一般的荣誉概念”。这本身不是 `all`，也不推出“每个荣誉实例”。实例量化必须显式建立 individual 成员域并绑定实际变量；“每一种德性”也须用独立的 virtue 域与范围。修复例将 `ἕκαστον αὐτῶν` 对前列荣誉、愉悦、理智的分配与 `πᾶσαν ἀρετήν` 的德性分配分开保存；不把一项的 πᾶσαν 扩给其余项。

restricted 指称保存 base、some/described、受限成员层级与证据。后续提及若沿用该指称，必须用 `inherits_from` 链接同一指称的先前 mention；检查器拒绝丢失的、错指的或成环的继承链接。首提及须与限制证据相交。若限制是否延续尚未判定，应另留 anonymous 指称或弃答并记录歧义。空字段既不是 all，也不是“与前文相同”的证明。检查器无法从两个希腊词形自行发现模型漏掉了本应存在的继承关系。

## 发言者、主体、作用域与未知

statement 的 voice 分别记录 speaker、可知时的 speaker_ref 和 asserted/reported/open commitment；force 区分一般断言、定义、问句、假设及条件前/后件片段。speaker 不自动等于行为的 subject，也不自动等于 attitude 的 holder。

条件、否定、潜在/表象模态、时态分布和信念放入实际包围目标命题的 AST 节点。条件片段须标 `antecedent_fragment/consequent_fragment`，不可单独作为无条件事实。前件内部的存在变量不在后件自由可用；有限语言不能忠实处理的跨域见证交接应弃答。并列的选择主句与所归属的成功信念可作为 `and` 的两个子项；信念子项不使主句自动降为信念，也不使信念内容成为客观成功。

## 证据与支持标签

跨度保存 context_id、章内 start/end 和逐字 text。按 Unicode 码点、零基半开区间读取，不作 Unicode 规范化。先检查精确子串，再独立检查词边界：字母、组合符、数字、下划线及已列的希腊/常见撇号相邻时视作词内连续。窗口边缘使用 guard。此规则能拒绝已知的 `θόν` 词内起截；它不是完整希腊文分词器，不判断证据是否充分或是否最短。

每个 AST 节点恰有一条 support 记录。evidence 与 antecedent_evidence 也都接受逐字和边界检查。

- `explicit`：所需关系/范围由已出现的词法句法表达；正常代词回指和语法一致性可以仍是 explicit。记录指向哪次 mention，不能因“有回指”一概降低标签。
- `ellipsis`：缺少词汇化的谓词、名词或论元，需要从明确前文补回；必须给 antecedent_evidence 并写明补回什么。仅有代词，不自动构成 ellipsis。
- `interpretive`：结构或身份判断实质依赖语境取舍，而非仅凭显式语法；说明所选读法与未排除项。它不是统一的“低置信度”分数。

标签本身的语义选择仍靠审阅。检查器只查取值、证据结构及 ellipsis 的回接是否存在；不能自动裁决某个代词的唯一先行项。

## 独立 P 投影

`project_p.py` 是后续独立步骤。它要求额外 review 文件，明确列出获准的 atom ID 和命名端点映射。仅允许作者采纳的一般/直接断言中的肯定 `choose_for`，且只穿过 `and` 和 `always`；拒绝条件、潜在/表象模态、否定、信念/转述、量词及未解 force 中的关系。当前保守子语言不导出量化命题，不表示它们语义上必然不成立。

两端必须是经复核的不同 named good-kind 指称；导出方向固定 `P(end,item)`。own-sake 仍是一元记录，永不由此生成自环。拒绝未指名端点，不猜成某个命名善。投影只给局部边及来源节点，不生成相容语境 Ω、逐边准入集 A_e、闭包、总体金标或自动完整性结论；这些仍须另据原文确定。

## 短诊断协议与回归解释

先运行 schema/引用/跨度检查，再检查类型、绑定、域、继承和支持覆盖；失败只报告首批明确结构问题。最后另行审读原文、绑定的语义对象、域层级、标签与发言立场。诊断类别是非穷尽的：SCHEMA、REFERENCE、SPAN_TEXT、SPAN_BOUNDARY、TYPE、FREE_VAR/UNUSED_BINDER、INHERITANCE、COMPARISON、SUPPORT_*。结构通过不等于原文正确；同型却绑错对象通常仍可能通过。

`examples/repaired/development-repairs.json` 是本执行者编制的旧材料结构修复；不是修改原始输出，也不是重新执行模型。`examples/broken/` 存独立的 replace/remove 故意损坏说明，由 `run_regressions.py` 在内存中应用。没有把故意损坏样本当成模型实际新犯的错误。

| 具名回归 | 修复的连接 | 可机械拒绝的对应损坏 |
|---|---|---|
| minimal U03.P01 | goods 域变量进入 about 的 topic 角色；论证保留 argument 角色 | 将 good 变量放入 argument 角色会类型失败 |
| minimal U04.P09 | some end 与 all practical matters 两个不同域/变量 | 域互换造成角色类型失败；存在变量不出现则空绑定失败 |
| minimal U04.P12 | plurality 绑定 ends 域的实际变量 | 改为空角色/不使用变量则失败 |
| guided U04.P012/P013 | 旧 [480,504) 修整为 [485,504) | 精确但词内开始的旧片段失败 |
| A07 限定继承 | restricted pleasure 在后提及显式继承 | 删除继承链接失败 |
| minimal U04.P22/P25 比较合同 | finality 明示且两项均为 good kind | 缺维度或论证占比较项失败 |
| guided U05.P008–P011 | 列举分配与 every virtue 分开 | 类型相同的错误域未必失败，必须读原文 |

机器拒绝的是这些新编码的明确结构错误，并不证明自动读懂/修复了旧输出。`examples/needs-source-review/` 特意保留语法类型有效而源文域错误的通过例，作为能力边界。实际结果见 `validation-results.json`、`validation-report.md`。

## 使用与冻结

```bash
python round-006/interface/run_regressions.py
python round-006/interface/validate.py PACKET.json ANNOTATION.json --output RESULT.json
python round-006/interface/project_p.py PACKET.json ANNOTATION.json REVIEW.json
```

新片段仅在冻结之后制成 packet。`minimal-prompt.txt` 与 `guided-prompt.txt` 使用同一合同/schema；各条件一次的输出另存原始记录，不据此主张因果提示增益。旧规则基线保持旧范围，不强制扩到新材料。合同、schema、程序、提示、旧材料回归、实际结果和旧来源散列列入 `freeze_manifest.json`；冻结后修订必须另有版本和理由，不覆盖本次冻结字节。
