# 实验原典底本与来源索引

本目录收录截至 2026-10-27 实际用于原典核读和有限诊断的固定希腊文底本。完整 XML 包含《尼各马可伦理学》十卷；本项目实际核读的希腊文范围仅为第一卷 I.1、I.2、I.5、I.6、I.7、I.8。保存全文便于复现定位，不表示全书已经研究或作为模型输入。

## 文件与取得状态

| 文件 | 内容 | 本次处理 |
|---|---|---|
| `tlg0086.tlg010.perseus-grc2.xml` | 原始 TEI/XML，748234 字节 | 从既有固定快照逐字节复制；没有替换底本，也不称为本次新下载 |
| `source_metadata.original.json` | 首次取得时的项目来源记录 | 原样复制；原记录的取得日期为 2026-10-26 |
| `tei-header.original.txt` | 原始 XML 的完整 `teiHeader` 字节片段 | 原样抽取，保留责任者、许可、书目与修订记录；是元数据片段，不是独立 TEI 文献 |
| `manifest.json` | 来源身份、实际范围、许可和完整性字段 | 本次整理的机器可读索引 |
| `SHA256SUMS` | 上述文件及本说明的 SHA256 | 用于检查传输与保存后的字节完整性 |

原始 XML SHA256：`a203a8d2e793b06884b135c23a5726ce36fc4796a6651589becb7cdf86ee42ae`。

Git blob SHA-1：`e8a43ddc7d643fca148f1dda18dc6d34528a9b2b`。这是文件对象标识，**不是提交号**；当前未记录源仓库提交号。2026-10-27 通过源仓库文件接口复核，返回的 blob 与固定快照一致。上游 `master` 链接会随仓库更新；复现以本目录原始字节和哈希为准。

在本目录可运行 `sha256sum -c SHA256SUMS` 检查完整性。

## 版本、责任者与来源

- 作者：Aristotle；希腊文题名：*Ἠθικὰ Νικομάχεια*。
- 所据印刷版：Ingram Bywater 编，*Aristotelis Ethica Nicomachea*，Oxford: Clarendon Press，1894。
- 数字版：Perseus Digital Library Project／Trustees of Tufts University；TEI 标记数字发布为 Perseus 2.0（1996），并保留后续修订，最新一项头部记录为 2026-08-26。数字文件不等于 1894 年的印刷原件。
- 源仓库：[PerseusDL/canonical-greekLit](https://github.com/PerseusDL/canonical-greekLit)。[对应 XML 页面](https://github.com/PerseusDL/canonical-greekLit/blob/master/data/tlg0086/tlg010/tlg0086.tlg010.perseus-grc2.xml)。CTS 版本 URN：`urn:cts:greekLit:tlg0086.tlg010.perseus-grc2`。
- [Perseus 第一卷可读页面](https://beta.perseus.tufts.edu/urn:cts:greekLit:tlg0086.tlg010.perseus-grc2:1/)。网页用于阅读与定位，不替代已固定的 XML 字节，也不保证完整显示 TEI 编辑状态。
- TEI 指向的[同版印刷影像入口](https://archive.org/details/aristotelis00aristuoft/page/n11/mode/2up)仅保留定位；本次未取得、未逐页核对，不作为已经校勘过的影像证据。

保留上游文件名是既有复现接口的明确约定：该名已用于提取器和证据定位，可直接识别 CTS 版本。此处不另造作者—年份文件键，也不把印刷年代或数字发布年代当作当前字节的生成日期。

## 实际使用范围

| 材料 | 已有实际用途 | 本目录的收录决定 |
|---|---|---|
| 固定 Greek I.1、I.2、I.6、I.7 | 原典核读与十二例研究注释；其中五个既有例、六个目标跨度进入固定跨度开发诊断，提供四段去重上下文，I.7 为第一 TEI 段 | 收录其所属完整原始 XML；具体切片与解释属于相应证据 |
| 固定 Greek I.5 | I.5 接口诊断；输入为全章单个 TEI 段，分析读法 1649 码点 | 同一原始 XML，无新增版本 |
| 固定 Greek I.8 | I.8 顺序核对：完整核读与四题顺序诊断，分析读法 3627 码点；随后在 I.7—I.8 解释中连读这两章 | 同一原始 XML，无新增独立测试语料 |
| W. D. Ross 英译，[MIT Book I](https://classics.mit.edu/Aristotle/nicomachaen.1.i.html) | 早期对读 I.1—2、I.6—7；I.4—5、此前 I.8 作辅助语境 | 仅列来源，不镜像；未替代希腊文底本 |
| H. Rackham 英译，[Perseus](https://beta.perseus.tufts.edu/urn:cts:greekLit:tlg0086.tlg010.perseus-eng2/) | 早期同段交叉核对；曾显示 I.8—9 的若干背景段 | 仅列来源，不镜像；不把背景接触计为全文核读 |
| [arg-microtexts 作者仓库](https://github.com/peldszus/arg-microtexts) | 只检查 DTD 与一个英文 XML 的结构；没有建立语料集、训练或预测基准 | 不收录；不是本项目原典实验语料 |

哈希对象须分别识别：I.5 的分析正文 UTF-8 SHA256 为 `310d450a5b8d92da6b9994a9cb2c2f1cf848ec1edf36a2fe626f46aa0fa24fe3`；现有 `greek-I5.json` 整个文件的 SHA256 为 `421bc9317e9faff9c0f837c77b23615904364150e1f6258268405b052a804719`。两者对应同一章节的不同表示，不得混用。

其他理论、方法和历史研究文献属于参考来源；本目录不将参考文献总表扩充成实验输入集。辅助译本和未收录材料的再分发许可未在本包中认证，本包不给出镜像授权。

## 署名、许可与衍生读法

原始 TEI 的 `publicationStmt/availability` 明示 [Creative Commons Attribution-ShareAlike 4.0 International（CC BY-SA 4.0）](https://creativecommons.org/licenses/by-sa/4.0/)。许可原文保留在 XML 与 `tei-header.original.txt`；本说明没有重写原许可声明。许可全文见 [CC 官方法律文本](https://creativecommons.org/licenses/by-sa/4.0/legalcode.en)。

发布该数字文本时保留 Aristotle、Ingram Bywater、Perseus Digital Library Project／Trustees of Tufts University 的署名、原始头部、源链接及许可链接；原始头部还保留其他编制责任者。可采用的简明署名为：

> Aristotle, *Ἠθικὰ Νικομάχεια*; Ingram Bywater (ed.), *Aristotelis Ethica Nicomachea*, Clarendon Press, Oxford, 1894. Digital text: Perseus Digital Library Project / Trustees of Tufts University, Perseus 2.0 (1996) and subsequent revisions, CC BY-SA 4.0. Source: PerseusDL/canonical-greekLit, `tlg0086.tlg010.perseus-grc2.xml`. This copy is byte-for-byte unchanged from the fixed source snapshot.

具体条件以官方法律文本为准：保留所提供的署名与许可信息、提供许可链接、注明改动；发布构成改编的衍生材料时遵守相同方式共享条款，不附加限制。本目录的第三方数字文本许可应独立保留；项目自有报告或代码的许可另行声明。

原始 XML 不作归一化。已有分析读法是衍生数据：按 XML 文档序串接文本与尾文本；排除 `del` 整个子树但保留其文字、位置和编辑状态记录，保留 `add` 文字及补字标记；只将连续空白合并为一个 U+0020，去除首尾空白。没有 Unicode NFC/NFD 转换、大小写折叠、去重音、标点替换或文字校订。偏移按每章 Unicode 码点计，使用从零开始的左闭右开区间。

I.2 有一处 `del`；I.7 有一处 `add` 和一处 `del`。将 XML 平铺为无标记文本会失去这些区别。以后发布提取文本或可读原文视图，应标为衍生文件、给出固定源哈希及上述规则，并保留可追溯的编辑记录。本次没有新增衍生原文视图、翻译或校勘。
