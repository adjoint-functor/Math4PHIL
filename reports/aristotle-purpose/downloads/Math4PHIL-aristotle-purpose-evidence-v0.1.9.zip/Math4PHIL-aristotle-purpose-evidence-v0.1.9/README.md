# Math4PHIL 原文与模型复核材料

对应报告《目的、条件与泛性质：亚里士多德幸福论的一个局部重构》v0.1.9（2026-10-28）。

| 内容 | 入口 |
|---|---|
| 14 条原文证据、中文释义与解释范围 | [可读索引](evidence/text-evidence.md)；[结构化记录](evidence/text-evidence.json) |
| 实际使用的固定希腊文底本与来源 | [download/README.md](download/README.md) |
| 两种提示各一次的 I.5 抽取诊断 | [evidence/diagnostic-I5/README.md](evidence/diagnostic-I5/README.md) |
| 固定底本、章字符串与原文跨度复核 | [code/verify_evidence.py](code/verify_evidence.py) |
| 报告中有限模型的计算复核 | [code/verify_models.py](code/verify_models.py) |
| 署名、材料许可与引用 | [NOTICE.md](NOTICE.md)；[CITATION.cff](CITATION.cff) |

## 离线复核

只需 Python 3 和标准库。在解压后的目录运行：

```bash
python3 code/verify_evidence.py
python3 code/verify_models.py
python3 evidence/diagnostic-I5/verify_offline.py
```

三个命令均应退出成功。第三个命令验证的是已保存事实，其中 minimal 原始输出预期保留两条结构报错；它不会把原始失败改成成功，也不会调用模型重新抽取。

`SHA256SUMS` 覆盖本包除该清单自身以外的全部文件；可用 `sha256sum -c SHA256SUMS` 检查文件完整性。

## 材料范围

原始 XML、来源头部、结构化原文记录，以及 I.5 诊断目录中的 23 个文件保留已有字节。`code/` 中的两个程序按报告所述读法和有限例编写，用于核对数据对应与计算结论。一般因子化判据和两关系命题的证明见报告；计算结果不代替证明，也不认证哲学释读。

报告所引现代论文、辅助译本和教材见报告书目与原站链接。完整 XML 的保存范围为十卷，报告的实际核读范围仍限于所声明的第一卷章节。

## 许可

许可范围见 [LICENSE.md](LICENSE.md) 与 [NOTICE.md](NOTICE.md)，完整协议位于 `LICENSES/`。原始记录保持既有字节；原典及其受原许可约束的衍生内容继续使用 CC BY-SA 4.0，项目自有复核软件使用 MIT，其他未另行标明的项目原创说明和提示文本使用 CC BY-NC-ND 4.0。
