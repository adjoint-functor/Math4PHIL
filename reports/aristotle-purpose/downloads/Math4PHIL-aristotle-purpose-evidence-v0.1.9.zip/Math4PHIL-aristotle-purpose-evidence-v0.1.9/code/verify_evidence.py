#!/usr/bin/env python3
"""Reconstruct the stated Greek reading and verify the report's saved spans."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = '{http://www.tei-c.org/ns/1.0}'
SOURCE_SHA256 = 'a203a8d2e793b06884b135c23a5726ce36fc4796a6651589becb7cdf86ee42ae'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def retained_text(element):
    parts = [element.text or '']
    for child in element:
        if child.tag != NS + 'del':
            parts.append(retained_text(child))
        parts.append(child.tail or '')
    return ''.join(parts)


def normalized(text):
    # Preserve every non-whitespace code point; deliberately no NFC/NFD.
    return ' '.join(text.split())


def main():
    data = json.loads((ROOT / 'evidence/text-evidence.json').read_text(encoding='utf-8'))
    xml = (ROOT / 'download/tlg0086.tlg010.perseus-grc2.xml').read_bytes()
    require(hashlib.sha256(xml).hexdigest() == SOURCE_SHA256 == data['source']['file_sha256'],
            'Fixed source SHA-256 mismatch')
    blob = hashlib.sha1(b'blob ' + str(len(xml)).encode('ascii') + b'\0' + xml).hexdigest()
    require(blob == data['source']['git_blob_sha1'], 'Fixed Git blob mismatch')
    tree = ET.fromstring(xml)
    book = tree.find('.//' + NS + 'div[@subtype="book"][@n="1"]')
    require(book is not None, 'Book I absent')
    chapters = data['chapters']
    require(set(chapters) == {'1.2', '1.5', '1.7', '1.8'}, 'Unexpected chapter selection')
    for cid, record in chapters.items():
        section = book.find(NS + 'div[@subtype="section"][@n="' + cid.split('.')[1] + '"]')
        require(section is not None, cid + ': section absent')
        paragraphs = section.findall(NS + 'p')
        text = ' '.join(normalized(retained_text(p)) for p in paragraphs)
        require(text == record['text'], cid + ': reconstructed reading differs')
        require(hashlib.sha256(text.encode('utf-8')).hexdigest() == record['text_sha256_utf8'],
                cid + ': chapter hash differs')
        require(len(paragraphs) == len(record['paragraphs']), cid + ': paragraph count differs')
        encoded = [e for e in section.iter() if e.tag in {NS + 'add', NS + 'del'}]
        require(len(encoded) == len(record['editorial']), cid + ': editorial count differs')
        for actual, saved in zip(encoded, record['editorial']):
            require(actual.tag == NS + saved['kind'], cid + ': editorial kind differs')
            require(normalized(''.join(actual.itertext())) == saved['normalized_text'],
                    cid + ': editorial text differs')
            if saved['kind'] == 'add':
                require(text[saved['start']:saved['end']] == saved['normalized_text'],
                        cid + ': addition span differs')
    require([r['id'] for r in data['records']] == ['E%02d' % n for n in range(1, 15)],
            'Expected E01-E14 exactly once and in order')
    subquotes = 0
    for record in data['records']:
        text = chapters[record['chapter_id']]['text']
        span = record['span']
        require(0 <= span['start'] < span['end'] <= len(text), record['id'] + ': invalid span')
        require(text[span['start']:span['end']] == record['exact_greek'],
                record['id'] + ': excerpt differs')
        for quote in record.get('quoted_in_report', []):
            span = quote['span']
            require(text[span['start']:span['end']] == quote['exact_greek'],
                    record['id'] + ': report subquote differs')
            subquotes += 1
    i5 = json.loads((ROOT / 'evidence/diagnostic-I5/input/greek-I5.json').read_text(encoding='utf-8'))
    require(i5['text'] == chapters['1.5']['text'], 'Diagnostic I.5 differs from the fixed reading')
    print(json.dumps({'ok': True, 'source_sha256': SOURCE_SHA256,
                      'chapters': len(chapters), 'evidence_records': len(data['records']),
                      'report_subquotes': subquotes, 'diagnostic_input_matches': True,
                      'scope': 'Source identity and text correspondence, not interpretation correctness.'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
