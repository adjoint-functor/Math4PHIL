#!/usr/bin/env python3
"""Compute the finite examples stated in Math4PHIL report v0.1.9."""
from itertools import product
import json


def require(ok, message):
    if not ok:
        raise ValueError(message)


def closure(objects, edges):
    reach = set(edges) | {(x, x) for x in objects}
    require(all(x in objects and y in objects for x, y in reach), 'Edge outside object set')
    for middle in objects:
        for source in objects:
            for target in objects:
                if (source, middle) in reach and (middle, target) in reach:
                    reach.add((source, target))
    return reach


def initials(objects, reach):
    return {x for x in objects if all((x, y) in reach for y in objects)}


def quotient(objects, reach):
    return {frozenset(y for y in objects if (x, y) in reach and (y, x) in reach)
            for x in objects}


def thin_category_check(objects, reach):
    # Morphisms are the ordered pairs in reach; composition (a,b);(b,c)=(a,c).
    def compose(first, second):
        require(first in reach and second in reach and first[1] == second[0],
                'Morphisms not composable')
        result = (first[0], second[1])
        require(result in reach, 'Composite missing')
        return result

    require(all((x, x) in reach for x in objects), 'Identity missing')
    require(all((a, c) in reach for a, b in reach for b2, c in reach if b == b2),
            'Composition not closed')
    for arrow in reach:
        require(compose((arrow[0], arrow[0]), arrow) == arrow, 'Left identity fails')
        require(compose(arrow, (arrow[1], arrow[1])) == arrow, 'Right identity fails')
    for a, b, c, d in product(objects, repeat=4):
        if {(a, b), (b, c), (c, d)} <= reach:
            left = compose(compose((a, b), (b, c)), (c, d))
            right = compose((a, b), compose((b, c), (c, d)))
            require(left == right and left in reach, 'Associativity fails')


def main():
    objects = ('h', 'o', 'p', 'n', 'v')
    p = {('h', x) for x in objects if x != 'h'}
    reach = closure(objects, p)
    thin_category_check(objects, reach)
    require(initials(objects, reach) == {'h'}, 'Section 2: initial objects differ')

    objects3 = ('h', 's', 'a')
    reach3 = closure(objects3, {('h', 's'), ('h', 'a')})
    thin_category_check(objects3, reach3)
    require(initials(objects3, reach3) == {'h'}, 'Section 4.2: initial objects differ')
    records = [{'graph': frozenset(reach3), 'answer': answer} for answer in (0, 1)]
    fibers = {}
    for record in records:
        fibers.setdefault(record['graph'], set()).add(record['answer'])
    require(any(len(values) > 1 for values in fibers.values()),
            'Section 4.2: missing same-graph/different-answer witness')

    objects2 = ('h', 'c')
    p2 = {('h', 'c')}
    c2 = {('c', 'h')}
    purpose = closure(objects2, p2)
    mixed = closure(objects2, p2 | c2)
    thin_category_check(objects2, purpose)
    thin_category_check(objects2, mixed)
    require(initials(objects2, purpose) == {'h'}, 'Section 5: purpose initials differ')
    require(initials(objects2, mixed) == {'h', 'c'}, 'Section 5: mixed initials differ')
    require(quotient(objects2, mixed) == {frozenset(objects2)}, 'Section 5: quotient differs')
    states = [(rh, rc) for rh, rc in product((0, 1), repeat=2) if rh <= rc]
    require(states == [(0, 0), (0, 1), (1, 1)], 'Section 5.2: allowed states differ')
    require((0, 1) in states, 'Section 5.2: missing insufficiency witness')

    places = ('A', 'B', 'C', 'D')
    edges = {('A', 'B'), ('B', 'C'), ('C', 'D'), ('A', 'C')}
    original = closure(places, edges)
    extended = closure(places, edges | {('B', 'A')})
    require(initials(places, original) == {'A'}, 'First background: initials differ')
    require(initials(places, extended) == {'A', 'B'}, 'Second background: initials differ')
    require(quotient(places, extended) == {frozenset('AB'), frozenset('C'), frozenset('D')},
            'Second background: quotient classes differ')
    print(json.dumps({'ok': True, 'section_2_initial_objects': ['h'],
                      'section_4_2_same_graph_answers': [0, 1],
                      'section_5_purpose_initials': ['h'],
                      'section_5_mixed_initials': ['h', 'c'],
                      'section_5_mixed_quotient': [['h', 'c']],
                      'section_5_2_allowed_states': states,
                      'background_extended_quotient': [['A', 'B'], ['C'], ['D']],
                      'scope': 'Finite examples only; general proofs and textual justification remain in the report.'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
